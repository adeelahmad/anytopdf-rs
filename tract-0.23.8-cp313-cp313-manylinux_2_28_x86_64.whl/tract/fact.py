from ctypes import *
from tract.bindings import TractError, check, lib
from .dim import Dim

class InferenceFact:
    """
    Tract inference fact, to be used with InferenceModel.

    It can represent partial type and shape information of a Tensor during model analysis.
    """
    def __init__(self, ptr):
        self.ptr = ptr

    def __del__(self):
        if self.ptr:
            check(lib.tract_inference_fact_destroy(byref(self.ptr)))

    def __str__(self):
        return self.dump()

    def _valid(self):
        if self.ptr == None:
            raise TractError("invalid inference fact (maybe already consumed ?)")

    def dump(self) -> str:
        """Return a human-readable representation of the fact."""
        self._valid()
        cstring = c_char_p();
        check(lib.tract_inference_fact_dump(self.ptr, byref(cstring)))
        result = str(cstring.value, "utf-8")
        lib.tract_free_cstring(cstring)
        return result

class Fact:
    """
    Tract-core fact, to be used with Model.

    It always contains the full shape (sometimes using symbolic dimensions) and item type.
    In some situation it can also contain the constant value of the associated tensor.
    """
    def __init__(self, ptr):
        self.ptr = ptr

    def __del__(self):
        if self.ptr:
            check(lib.tract_fact_destroy(byref(self.ptr)))

    def __str__(self):
        return self.dump()

    def _valid(self):
        if self.ptr == None:
            raise TractError("invalid fact (maybe already consumed ?)")

    def datum_type(self) -> int:
        """Return the element type of the fact as a ``DatumType`` integer."""
        self._valid()
        dt = c_uint32()
        check(lib.tract_fact_datum_type(self.ptr, byref(dt)))
        return dt.value

    def rank(self) -> int:
        """Return the number of dimensions (axes) of the tensor."""
        self._valid()
        rank = c_size_t()
        check(lib.tract_fact_rank(self.ptr, byref(rank)))
        return rank.value

    def dim(self, axis: int) -> Dim:
        """Return the :class:`~tract.dim.Dim` for the given axis."""
        self._valid()
        ptr = c_void_p();
        check(lib.tract_fact_dim(self.ptr,  c_size_t(axis), byref(ptr)))
        return Dim(ptr)

    def dump(self) -> str:
        """Return a human-readable representation of the fact."""
        self._valid()
        cstring = c_char_p();
        check(lib.tract_fact_dump(self.ptr, byref(cstring)))
        result = str(cstring.value, "utf-8")
        lib.tract_free_cstring(cstring)
        return result

    def dims(self):
        """Return a list of :class:`~tract.dim.Dim` for all axes."""
        return [ self.dim(axis) for axis in range(self.rank()) ]
